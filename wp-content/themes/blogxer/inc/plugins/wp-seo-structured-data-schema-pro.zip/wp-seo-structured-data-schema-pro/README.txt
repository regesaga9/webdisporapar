Thanks for using our plugin

== Changelog ==

<h4>= 1.4.8 ( July 11, 2023) =</h4>
<pre> * Fixed: Custom Snippet.
</pre>

<h4>= 1.4.7 ( June 21, 2023) =</h4>
<pre> * Added: Custom Snippet added.
</pre>

<h4>= 1.4.6 (Sept 28, 2022) =</h4>
<pre> * Fixed: Recipe Issue Fixed.
</pre>

<h4>= 1.0.5  ( 23 August, 2022 ) =</h4>
<pre> * Fixed: Schema Issue Fixed
</pre>

= 1.4.4 (Sept 15, 2022) =
* Added: New Schema Type TechArticle, MedicalWebPage, CollectionPage;

= 1.4.3 (Apr 04, 2022) =
* Fixed: Support Issue;
