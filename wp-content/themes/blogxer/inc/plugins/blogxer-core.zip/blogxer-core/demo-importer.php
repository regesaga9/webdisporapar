<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Blogxer_Core;

use \FW_Ext_Backups_Demo;
use \WPCF7_ContactFormTemplate;

if ( ! defined( 'ABSPATH' ) ) exit;

class Demo_Importer {

	public function __construct() {
		add_filter( 'plugin_action_links_rt-demo-importer/rt-demo-importer.php', array( $this, 'add_action_links' ) ); // Link from plugins page 
		add_filter( 'rt_demo_installer_warning', array( $this, 'data_loss_warning' ) );
		add_filter( 'fw:ext:backups-demo:demos', array( $this, 'demo_config' ) );
		add_action( 'fw:ext:backups:tasks:success:id:demo-content-install', array( $this, 'after_demo_install' ) );
		//add_filter( 'fw:ext:backups:add-restore-task:image-sizes-restore', '__return_false' ); // Enable it to skip image restore step
	}

	public function add_action_links( $links ) {
		$mylinks = array(
			'<a href="' . esc_url( admin_url( 'tools.php?page=fw-backups-demo-content' ) ) . '">'.__( 'Install Demo Contents', 'blogxer-core' ).'</a>',
		);
		return array_merge( $links, $mylinks );
	}

	public function data_loss_warning( $links ) {
		$html  = '<div style="margin-top:20px;color:#f00;font-size:20px;line-height:1.3;font-weight:600;margin-bottom:40px;border-color: #f00;border-style: dashed;border-width: 1px 0;padding:10px 0;">';
		$html .= __( 'Warning: All your old data will be lost if you install One Click demo data from here, so it is suitable only for a new website.', 'blogxer-core');
		 $html .= __( ' ( If one click demo import does not work please try manual demo import <a href="https://radiustheme.com/demo/wordpress/themes/blogxer/docs/#demo-manual" target="__blank" style="text-decoration:none; color:#444444;">check documentation</a> )', 'blogxer-core' );
		$html .= '</div>';
		return $html;
	}

	public function demo_config( $demos ) {
		$demos_array = array(
			'demo1' => array(
				'title' => __( 'Home 1', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot1.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/',
			),
			'demo2' => array(
				'title' => __( 'Home 2', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot2.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-2/',
			),
			'demo3' => array(
				'title' => __( 'Home 3', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot3.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-3/',
			),
			'demo4' => array(
				'title' => __( 'Home 4', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot4.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-4/',
			),
			'demo5' => array(
				'title' => __( 'Home 5', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot5.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-5/',
			),
			'demo6' => array(
				'title' => __( 'Home 6', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot6.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-6/',
			),
			'demo7' => array(
				'title' => __( 'Home 7', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot7.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-7/',
			),
			'demo8' => array(
				'title' => __( 'Home 8', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot8.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-8/',
			),
			'demo9' => array(
				'title' => __( 'Home 9', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot9.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-9/',
			),
			'demo10' => array(
				'title' => __( 'Home 10', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot10.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-10/',
			),
			'demo11' => array(
				'title' => __( 'Home 11', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot11.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-11/',
			),
			'demo12' => array(
				'title' => __( 'Home 12', 'blogxer-core' ),
				'screenshot' => plugins_url( 'screenshots/screenshot12.jpg', __FILE__ ),
				'preview_link' => 'https://radiustheme.com/demo/wordpress/themes/blogxer/home-12/',
			),
		);

		$download_url = 'http://demo.radiustheme.com/wordpress/demo-content/blogxer/';

		foreach ($demos_array as $id => $data) {
			$demo = new FW_Ext_Backups_Demo($id, 'piecemeal', array(
				'url' => $download_url,
				'file_id' => $id,
			));
			$demo->set_title($data['title']);
			$demo->set_screenshot($data['screenshot']);
			$demo->set_preview_link($data['preview_link']);

			$demos[ $demo->get_id() ] = $demo;

			unset($demo);
		}

		return $demos;
	}

	public function after_demo_install( $collection ){
		// Update front page id
		$demos = array(
			'demo1'  => 7,
			'demo2'  => 562,
			'demo3'  => 599,
			'demo4'  => 615,
			'demo5'  => 625,
			'demo6'  => 645,
			'demo7'  => 654,
			'demo8'  => 664,
			'demo9'  => 666,
			'demo10'  => 821,
			'demo11'  => 855,
			'demo12'  => 880,
		);

		$data = $collection->to_array();

		foreach( $data['tasks'] as $task ) {
			if( $task['id'] == 'demo:demo-download' ){
				$demo_id = $task['args']['demo_id'];
				$page_id = $demos[$demo_id];
				update_option( 'page_on_front', $page_id );
				flush_rewrite_rules();
				break;
			}
		}

		// Update contact form 7 email
		$cf7ids = array( 109 );
		foreach ( $cf7ids as $cf7id ) {
			$mail = get_post_meta( $cf7id, '_mail', true );

			if(empty($mail)){
	            $mail = array();
	        }
	        
			$mail['recipient'] = get_option( 'admin_email' );

			if ( class_exists( 'WPCF7_ContactFormTemplate' ) ) {
				$pattern = "/<[^@\s]*@[^@\s]*\.[^@\s]*>/"; // <email@email.com>
				$replacement = '<'. WPCF7_ContactFormTemplate::from_email().'>';
				$mail['sender'] = preg_replace($pattern, $replacement, $mail['sender']);
			}
			
			update_post_meta( $cf7id, '_mail', $mail );		
		}

		// Update WooCommerce emails
		$admin_email = get_option( 'admin_email' );
		update_option( 'woocommerce_email_from_address', $admin_email );
		update_option( 'woocommerce_stock_email_recipient', $admin_email );
	}
}

new Demo_Importer;