document.addEventListener("DOMContentLoaded", function(){ window.addEventListener("DOMContentLoaded", function(){
	UAGBForms.init( {"block_id":"c39a0979","reCaptchaEnable":false,"reCaptchaType":"v2","reCaptchaSiteKeyV2":"","reCaptchaSecretKeyV2":"","reCaptchaSiteKeyV3":"","reCaptchaSecretKeyV3":"","afterSubmitToEmail":"abc@gmail.com","afterSubmitCcEmail":"","afterSubmitBccEmail":"","afterSubmitEmailSubject":"Pengiriman Formulir","sendAfterSubmitEmail":true,"confirmationType":"message","hidereCaptchaBatch":false,"captchaMessage":"Silakan isi captcha di atas.","confirmationUrl":""}, '.uagb-block-c39a0979', 776 );
});
window.addEventListener( 'load', function() {
	UAGBButtonChild.init( '.uagb-block-36f77ae1' );
});
window.addEventListener("DOMContentLoaded", function(){
	UAGBForms.init( {"block_id":"d276cdda","reCaptchaEnable":false,"reCaptchaType":"v2","reCaptchaSiteKeyV2":"","reCaptchaSecretKeyV2":"","reCaptchaSiteKeyV3":"","reCaptchaSecretKeyV3":"","afterSubmitToEmail":"abc@gmail.com","afterSubmitCcEmail":"","afterSubmitBccEmail":"","afterSubmitEmailSubject":"Pengiriman Formulir","sendAfterSubmitEmail":true,"confirmationType":"message","hidereCaptchaBatch":false,"captchaMessage":"Silakan isi captcha di atas.","confirmationUrl":""}, '.uagb-block-d276cdda', 776 );
});
 });